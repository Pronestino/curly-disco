import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity, ScrollView, TextInput, KeyboardAvoidingView, Platform } from 'react-native';

const HomeScreen = ({ user, navigation }) => {
  const [metas, setMetas] = useState([]);
  const [metaName, setMetaName] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const addMeta = () => {
    if (metaName) {
      setMetas((prevMetas) => [
        ...prevMetas,
        { id: Math.random().toString(), nomeMeta: metaName, favorito: false },
      ]);
      setMetaName('');
      setErrorMessage('');
    } else {
      setErrorMessage('Por favor, insira um nome para a meta.');
    }
  };

  const toggleFavorite = (index) => {
    setMetas((prevMetas) =>
      prevMetas.map((meta, i) =>
        i === index ? { ...meta, favorito: !meta.favorito } : meta
      )
    );
  };

  const favoriteMetas = metas.filter(meta => meta.favorito);
  const otherMetas = metas.filter(meta => !meta.favorito);

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView>
        <Text style={styles.welcomeText}>Bem-vindo ao MetaGo!</Text>
        <Text style={styles.userText}>Metas de {user.apelido}</Text>

        <TouchableOpacity 
          style={styles.profileButton} 
          onPress={() => navigation.navigate('Perfil', { user })}
        >
          <Text style={styles.profileButtonText}>Perfil</Text>
        </TouchableOpacity>

        <TextInput
          style={styles.input}
          placeholder="Nome da Meta"
          value={metaName}
          onChangeText={setMetaName}
        />
        <Button title="Adicionar Meta" onPress={addMeta} color="#000" />

        {errorMessage ? <Text style={styles.errorText}>{errorMessage}</Text> : null}

        <Text style={styles.sectionTitle}>Metas Favoritas</Text>
        {favoriteMetas.length > 0 ? (
          <ScrollView>
            {favoriteMetas.map((meta, index) => (
              <View key={meta.id} style={styles.metaCard}>
                <Text style={styles.metaTitle}>{meta.nomeMeta}</Text>
                <TouchableOpacity onPress={() => toggleFavorite(index)}>
                  <Text style={styles.favoriteButton}>❤️</Text>
                </TouchableOpacity>
              </View>
            ))}
          </ScrollView>
        ) : (
          <Text style={styles.noMetaText}>Nenhuma meta favorita ainda.</Text>
        )}

        <Text style={styles.sectionTitle}>Outras Metas</Text>
        <ScrollView>
          {otherMetas.map((meta, index) => (
            <View key={meta.id} style={styles.metaCard}>
              <Text style={styles.metaTitle}>{meta.nomeMeta}</Text>
              <TouchableOpacity onPress={() => toggleFavorite(index)}>
                <Text style={styles.favoriteButton}>🤍</Text>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#ffffff',
  },
  welcomeText: {
    fontSize: 22,
    fontWeight: 'bold',
    marginVertical: 15,
    textAlign: 'center',
    color: '#000',
  },
  userText: {
    fontSize: 18,
    marginBottom: 20,
    color: '#000',
    textAlign: 'center',
  },
  profileButton: {
    marginVertical: 15,
    alignItems: 'center',
  },
  profileButtonText: {
    fontSize: 18,
    color: '#000',
  },
  input: {
    borderWidth: 1,
    borderColor: '#000',
    padding: 10,
    marginBottom: 15,
    borderRadius: 5,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
    color: '#000',
  },
  metaCard: {
    padding: 15,
    marginVertical: 5,
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 10,
    backgroundColor: '#ffffff',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metaTitle: {
    fontWeight: 'bold',
    fontSize: 18,
    color: '#000',
  },
  favoriteButton: {
    fontSize: 24,
  },
  noMetaText: {
    textAlign: 'center',
    color: '#000',
  },
  errorText: {
    color: 'red',
    textAlign: 'center',
    marginVertical: 10,
  },
});

export default HomeScreen;
