import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Text } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';



const LoginScreen = ({ onLogin, navigation }) => {
  const [apelido, setApelido] = useState('');
  const [senha, setSenha] = useState('');

  const handleLogin = async () => {
    if (apelido && senha) {
      const storedApelido = await AsyncStorage.getItem('apelido');
      const storedSenha = await AsyncStorage.getItem('senha');

      if (apelido === storedApelido && senha === storedSenha) {
        const userData = { apelido, senha }; // Passa os dados do usuário
        onLogin(userData); // Atualiza o estado no App
        navigation.navigate('Home'); // Navega para HomeScreen
      } else {
        alert("Credenciais inválidas.");
      }
    } else {
      alert("Por favor, preencha todos os campos.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>MetaGo</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu apelido"
        value={apelido}
        onChangeText={setApelido}
      />
      <TextInput
        style={styles.input}
        placeholder="Digite sua senha"
        secureTextEntry={true}
        value={senha}
        onChangeText={setSenha}
      />
      <Button title="Login" onPress={handleLogin} color="#000" />
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#000',
  },
  input: {
    borderWidth: 1,
    borderColor: '#000',
    padding: 10,
    marginBottom: 15,
    borderRadius: 5,
  },
});

export default LoginScreen;
