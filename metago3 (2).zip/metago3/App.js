import React, { useState, useEffect } from 'react'; 
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as Notifications from 'expo-notifications';
import CadastroScreen from './screens/CadastroScreen'; // Verifique o caminho
import LoginScreen from './screens/LoginScreen'; // Verifique o caminho
import HomeScreen from './screens/HomeScreen'; // Verifique o caminho
import PerfilScreen from './screens/PerfilScreen'; // Verifique o caminho
import { ImageBackground } from 'react-native';


const Stack = createStackNavigator();

const App = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    registerForPushNotificationsAsync(); // Registra para notificações
    scheduleNotification(); // Agenda a primeira notificação
  }, []);

  const registerForPushNotificationsAsync = async () => {
    const { status } = await Notifications.getPermissionsAsync();
    if (status !== 'granted') {
      const { status: newStatus } = await Notifications.requestPermissionsAsync();
      if (newStatus !== 'granted') {
        alert('Você precisa permitir notificações para usar esse recurso!');
        return;
      }
    }
  };

  const scheduleNotification = async () => {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Lembrete!",
        body: 'É hora de verificar suas metas!',
      },
      trigger: {
        seconds: 24 * 60 * 60, // 24 horas
        repeats: true, // Repete a cada 24 horas
      },
    });
  };

  const handleCadastro = (newUser) => {
    setUser(newUser);
  };

  const handleLogin = async (loginData) => {
    // Verifique se o apelido e a senha estão corretos
    if (user && user.apelido === loginData.apelido && user.senha === loginData.senha) {
      setUser(user);
    } else {
      alert("Apelido ou senha incorretos.");
    }
  };

  const handleSaveProfile = (updatedUser) => {
    setUser(updatedUser);
  };

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Cadastro">
        <Stack.Screen name="Cadastro">
          {(props) => <CadastroScreen {...props} onCadastro={handleCadastro} />}
        </Stack.Screen>
        <Stack.Screen name="Login">
          {(props) => <LoginScreen {...props} onLogin={handleLogin} />}
        </Stack.Screen>
        <Stack.Screen name="Home">
          {(props) => <HomeScreen {...props} user={user} />}
        </Stack.Screen>
        <Stack.Screen name="Perfil">
          {(props) => <PerfilScreen {...props} user={user} onSaveProfile={handleSaveProfile} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
