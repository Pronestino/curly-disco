import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

const MetaForm = ({ onAddMeta }) => {
  const [nomeMeta, setNomeMeta] = useState('');
  const [tempoInicial, setTempoInicial] = useState('');
  const [tempoFinal, setTempoFinal] = useState('');
  const [valor, setValor] = useState('');

  const handleSubmit = () => {
    onAddMeta({ nomeMeta, tempoInicial, tempoFinal, valor });
    setNomeMeta('');
    setTempoInicial('');
    setTempoFinal('');
    setValor('');
  };

  return (
    <View>
      <TextInput placeholder="Nome da Meta" value={nomeMeta} onChangeText={setNomeMeta} style={styles.input} />
      <TextInput placeholder="Tempo Inicial" value={tempoInicial} onChangeText={setTempoInicial} style={styles.input} />
      <TextInput placeholder="Tempo Final" value={tempoFinal} onChangeText={setTempoFinal} style={styles.input} />
      <TextInput placeholder="Valor" value={valor} onChangeText={setValor} style={styles.input} keyboardType="numeric" />
      <Button title="Adicionar Meta" onPress={handleSubmit} />
    </View>
  );
};

const styles = StyleSheet.create({
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginVertical: 5,
  },
});

export default MetaForm;
