import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

const ProfileForm = ({ onSave }) => {
  const [nome, setNome] = useState('');
  const [sobrenome, setSobrenome] = useState('');
  const [apelido, setApelido] = useState('');

  const handleSave = () => {
    onSave({ nome, sobrenome, apelido });
    setNome('');
    setSobrenome('');
    setApelido('');
  };

  return (
    <View>
      <TextInput placeholder="Nome" value={nome} onChangeText={setNome} style={styles.input} />
      <TextInput placeholder="Sobrenome" value={sobrenome} onChangeText={setSobrenome} style={styles.input} />
      <TextInput placeholder="Apelido" value={apelido} onChangeText={setApelido} style={styles.input} />
      <Button title="Salvar" onPress={handleSave} />
    </View>
  );
};

const styles = StyleSheet.create({
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginVertical: 5,
  },
});

export default ProfileForm;
